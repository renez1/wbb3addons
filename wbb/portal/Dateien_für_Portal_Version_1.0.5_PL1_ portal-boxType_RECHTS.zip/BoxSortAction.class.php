<?php
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');

class BoxSortAction extends AbstractAction {
	public $positions = array();
	public $boxTypes = array();

	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();

		if (isset($_POST['positions']) && is_array($_POST['positions'])) $this->positions = $_POST['positions'];
		if (isset($_POST['boxTypes']) && is_array($_POST['boxTypes'])) $this->boxTypes = $_POST['boxTypes'];
	}
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();

		
		reset($this->positions);
		while (list($key, $val) = each($this->positions)) {
			WCF::getDB()->sendQuery("UPDATE wbb".WBB_N."_portalboxes SET sortOrder='".$val."' WHERE boxID = '".$key."'");
		}
		reset($this->boxTypes);
		while (list($key, $val) = each($this->boxTypes)) {
			WCF::getDB()->sendQuery("UPDATE wbb".WBB_N."_portalboxes SET boxType='".$val."' WHERE boxID = '".$key."'");
 		}
		$this->executed();

		// forward to list page
		header('Location: index.php?page=PortalManagementList&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>
