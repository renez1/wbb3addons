<?php
require_once(WCF_DIR.'lib/page/SortablePage.class.php');
require_once(WCF_DIR.'lib/system/event/EventHandler.class.php');

class PortalManagementListPage extends SortablePage {
	public $itemsPerPage = 25;
	public $defaultSortField = 'sortOrder';
	public $templateName = 'boxList';
	public $boxIDs = array();
	public $markedBoxs = array();
	public $boxes = array();

	public function readParameters() {
		parent::readParameters();
	}
	public function validateSortField() {
		parent::validateSortField();

		switch ($this->sortField) {
			case 'boxName':
			case 'showInForum':
			case 'boxActivation':
			case 'sortOrder': break;
			default: $this->sortField = $this->defaultSortField;
		}
	}
	public function readData() {
		parent::readData();
		$this->readBoxes();
	}
	public function assignVariables() {
		parent::assignVariables();

		WCF::getTPL()->assign(array(
			'boxes' => $this->boxes,
			'boxcount' => $this->countItems()
		));
	}
	public function show() {
		WCFACP::getMenu()->setActiveMenuItem('wbb.acp.menu.link.content.portal');

		parent::show();
	}
	public function countItems() {
		parent::countItems();

		$sql = "SELECT	COUNT(*) AS count
				FROM	wbb".WBB_N."_portalboxes";
		$row = WCF::getDB()->getFirstRow($sql);

		return $row['count'];
	}
	protected function readBoxes() {
		$userIDs = '';
		$sql = "SELECT	boxID, boxName, boxType, sortOrder, boxActivation, showInForum
			FROM		wbb".WBB_N."_portalboxes boxes
			ORDER BY	boxes.boxType DESC, boxes.".$this->sortField." ".$this->sortOrder."
			LIMIT		".$this->itemsPerPage."
			OFFSET		".(($this->pageNo - 1) * $this->itemsPerPage);
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$this->boxes[] = $row;
		}
	}
}
?>
