<?php
class PortalBoxFactory  {

	protected $boxData = array();

	public function __construct() {
		self::selectBoxes();
		self::makeBoxData();
	}

	protected function selectBoxes() {
		$sql = "SELECT * FROM wbb".WBB_N."_portalboxes boxes WHERE boxes.boxActivation = '1' ORDER BY boxes.sortOrder ASC";
		$result = WBBCore::getDB()->sendQuery($sql);
		while($row = WBBCore::getDB()->fetchArray($result)) {
			$this->boxData['type'.$row['boxType']][$row['boxID']] = $row;
		}
	}

	protected function makeBoxData() {
		if(count($this->boxData)) {
			$boxType = null;
			foreach($this->boxData as $item => $boxData) {
				$boxType = $item;
				foreach($boxData as $item2 => $boxData2) {
					if(file_exists(WBB_DIR.'lib/system/portalbox/cachebuilder/'.$boxData2['cacheType'].'CacheBuilder.class.php')) {
						require_once(WBB_DIR.'lib/system/portalbox/cachebuilder/'.$boxData2['cacheType'].'CacheBuilder.class.php');
						$className = $boxData2['cacheType']."CacheBuilder";
						$boxObj = new $className;
						$this->data['type'.$boxData2['boxType']][$boxData2['boxID']] = $boxObj->execute($boxData2['boxID'],
						$boxData2['cacheBuilderClass'], 'type'.$boxData2['boxType'], $boxData2['minLifeTime']);
					}
					$this->data[$boxType][$boxData2['boxID']] = $this->parseBoxData($boxType, $boxData2['boxID']);
				}
			}
		}
	}

	protected function parseBoxData($boxType, $boxID) {
		$className = $this->boxData[$boxType][$boxID]['className'];
		if(file_exists(WBB_DIR.'lib/data/boxes/'.$className.'.class.php')) {
			require_once(WBB_DIR.'lib/data/boxes/'.$className.'.class.php');
		}
		else {
			echo "Klasse".$className." nicht vorhanden! Abbruch!";
			exit;
		}
		$boxObject = new $className($this->boxData[$boxType][$boxID], $this->boxData[$boxType][$boxID]['boxName']);
		return $boxObject->getData();
	}

	public function getType1Data() {
		if(isset($this->data['type1'])) return $this->data['type1'];
		else return array();
	}
	public function getType2Data() {
		if(isset($this->data['type2'])) return $this->data['type2'];
		else return array();
	}
	public function getType3Data() {
		if(isset($this->data['type3'])) return $this->data['type3'];
		else return array();
	}
}
?>