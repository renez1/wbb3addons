UPDATE `wcf1_package_installation_plugin` SET `priority`=255 WHERE `pluginName`='FileDeletePackageInstallationPlugin';
