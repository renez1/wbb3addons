ALTER TABLE `wcf1_user_guestbook_header` ADD `newEntries` INT( 10 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `entries`;
UPDATE wcf1_user_guestbook_header
   SET newEntries = (
        SELECT COUNT(*)
          FROM wcf1_user_guestbook u
         WHERE u.userID = userID
)
 WHERE lastEntry > userLastVisit;
