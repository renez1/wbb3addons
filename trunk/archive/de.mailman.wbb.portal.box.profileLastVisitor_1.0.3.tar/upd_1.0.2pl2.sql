DELETE FROM `wbb1_1_portalboxes`
 WHERE `boxName` = 'ProfileLastVisitorsBox';
