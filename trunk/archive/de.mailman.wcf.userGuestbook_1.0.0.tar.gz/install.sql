CREATE TABLE `wcf1_user_guestbook` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userID` int(10) unsigned NOT NULL,
  `fromUserID` int(10) unsigned NOT NULL,
  `text` mediumtext default NULL,
  `enableSmilies` tinyint(1) NOT NULL,
  `enableHtml` tinyint(1) NOT NULL,
  `enableBBCodes` tinyint(1) NOT NULL,
  `entryTime` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  INDEX `userID` (`userID`)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `wcf1_user_guestbook_header` (
  `userID` int(10) unsigned NOT NULL,
  `userLastVisit` int(10) unsigned NOT NULL default '0',
  `lastEntry` int(10) unsigned NOT NULL default '0',
  `entries` int(10) unsigned NOT NULL default '0',
  `views` int(10) unsigned NOT NULL default '0',
  `visitorID` int(10) unsigned NOT NULL default '0',
  `visitorLastVisit` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`userID`)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8;
