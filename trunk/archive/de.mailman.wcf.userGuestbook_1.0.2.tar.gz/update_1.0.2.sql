ALTER TABLE `wcf1_user_guestbook_header` ADD `lastEntryUserID` INT( 10 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `userLastVisit`;
